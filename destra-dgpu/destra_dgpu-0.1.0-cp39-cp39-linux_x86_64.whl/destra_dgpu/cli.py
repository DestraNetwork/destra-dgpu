import argparse
import os
import subprocess
import logging
from .utils import get_head_node_address, register_worker_node

def start_worker_node():
    parser = argparse.ArgumentParser(description="Start a GPU worker node")
    parser.add_argument("contract_address", type=str, help="Destra GPU RegistrySmart contract address")
    parser.add_argument("rpc_url", type=str, help="Ethereum RPC URL")
    args = parser.parse_args()

    private_key = os.getenv("NODE_OPERATOR_PRIVATE_KEY")
    if not private_key:
        raise EnvironmentError("NODE_OPERATOR_PRIVATE_KEY environment variable not set")

    head_node_address = get_head_node_address(args.contract_address, args.rpc_url)

    # Set environment variables to suppress Ray logs
    os.environ["RAY_LOG_TO_STDERR"] = "1"
    os.environ["RAY_LOGGER_LEVEL"] = "ERROR"

    # Start Ray on the worker node
    try:
        print(f"Starting GPU worker node and connecting to the head node...")
        subprocess.run(["ray", "start", f"--address={head_node_address}"], check=True)
        print(f"GPU Worker node started with head node address at {args.contract_address}")
        print(f"To stop your worker node, use command:")
        print(f"destra-gpu-stop-worker")
    except subprocess.CalledProcessError as e:
        print(f"Failed to start Ray on the worker node: {e}")
        return

    # Register the worker node
    print(f"Starting registration of your worker node with Destra GPU Regsitry...")
    register_worker_node(args.contract_address, args.rpc_url, head_node_address, private_key)

def stop_worker_node():
    try:
        subprocess.run(["ray", "stop"], check=True)
        print("Worker node stopped successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to stop the worker node: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Destra GPU CLI")
    subparsers = parser.add_subparsers(dest="command")

    start_parser = subparsers.add_parser("start", help="Start a GPU worker node")
    start_parser.add_argument("contract_address", type=str, help="Smart contract address")
    start_parser.add_argument("rpc_url", type=str, help="Ethereum RPC URL")

    stop_parser = subparsers.add_parser("stop", help="Stop the GPU worker node")

    args = parser.parse_args()

    if args.command == "start":
        start_worker_node()
    elif args.command == "stop":
        stop_worker_node()
    else:
        parser.print_help()
