from web3 import Web3
import ray

# Define the contract ABI
CONTRACT_ABI = [
    {
        "constant": True,
        "inputs": [],
        "name": "headNodeAddress",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [],
        "name": "registerGPUNode",
        "outputs": [],
        "payable": True,
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [{"name": "_nodeOperator", "type": "address"}, {"name": "_nodeId", "type": "uint256"}],
        "name": "verifyGPUNode",
        "outputs": [{"name": "", "type": "bool"}, {"name": "", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    # Add other relevant ABI entries if needed
]

def get_head_node_address(contract_address: str, rpc_url: str) -> str:
    w3 = Web3(Web3.HTTPProvider(rpc_url))
    if not w3.is_connected():
        raise ConnectionError("Failed to connect to the Ethereum network")

    contract = w3.eth.contract(address=contract_address, abi=CONTRACT_ABI)
    head_node_address = contract.functions.headNodeAddress().call()
    return head_node_address

def register_worker_node(contract_address: str, rpc_url: str, head_node_address: str, private_key: str):
    w3 = Web3(Web3.HTTPProvider(rpc_url))
    if not w3.is_connected():
        raise ConnectionError("Failed to connect to the Ethereum network")

    account = w3.eth.account.from_key(private_key)  # Updated method to use from_key
    contract = w3.eth.contract(address=contract_address, abi=CONTRACT_ABI)

    gas_price = w3.eth.gas_price

    transaction = contract.functions.registerGPUNode().build_transaction({
        'from': account.address,
        'value': w3.to_wei(0, 'ether'),  # Assuming depositAmount is 0.5 ETH, adjust if needed
        'nonce': w3.eth.get_transaction_count(account.address),
        'gas': 2000000,
        'gasPrice': gas_price
    })

    signed_txn = w3.eth.account.sign_transaction(transaction, private_key=private_key)
    tx_hash = w3.eth.send_raw_transaction(signed_txn.rawTransaction)
    print(f"Worker node registered with the Destra GPU Registry; transaction hash: {w3.to_hex(tx_hash)}")

def verify_gpu_node(contract_address: str, rpc_url: str, node_operator: str, node_id: int) -> bool:
    w3 = Web3(Web3.HTTPProvider(rpc_url))
    if not w3.is_connected():
        raise ConnectionError("Failed to connect to the Ethereum network")

    contract = w3.eth.contract(address=contract_address, abi=CONTRACT_ABI)
    is_registered, registration_time = contract.functions.verifyGPUNode(node_operator, node_id).call()
    return is_registered, registration_time

def destra_ray_init(contract_address: str, rpc_url: str):
    head_node_address = get_head_node_address(contract_address, rpc_url)
    ray.init(address=head_node_address)
